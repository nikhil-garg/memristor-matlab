function y=tc(Ra,Rb,Eref)
% Voltage divider test circuit
y=Eref*Rb/(Ra+Rb);
