function c = frac(x)
% Fractional value of x
c=x-floor(x);