%VAPP: Credits
%-------------
%
%A. Gokcen Mahmutoglu   - design and implementation of the backend,
%                         implementation of additional functionalities to the
%                         frontend.
%
%Karthik Aadithya       - design and implementation of the frontend AST parser.
%
%Xufeng Wang            - implementation of file name/line number information
%                         for tokens in the frontend.
%
%Tianshi Wang           - consultation on MAPP, ModSpec, Verilog-A, etc..
%
%Jaijeet Roychowdhury   - project lead (no code contributions to VAPP).
%

help VAPPcredits;
